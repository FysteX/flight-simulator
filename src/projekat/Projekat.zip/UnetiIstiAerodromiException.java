package projekat;

public class UnetiIstiAerodromiException extends Exception {

	public UnetiIstiAerodromiException() {}

}
