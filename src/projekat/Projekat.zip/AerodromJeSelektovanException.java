package projekat;

public class AerodromJeSelektovanException extends Exception {

	public AerodromJeSelektovanException() {}

}
