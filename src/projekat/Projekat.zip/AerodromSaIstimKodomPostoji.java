package projekat;

public class AerodromSaIstimKodomPostoji extends Exception {

	public AerodromSaIstimKodomPostoji() {}

}
