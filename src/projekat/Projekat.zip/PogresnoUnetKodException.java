package projekat;

public class PogresnoUnetKodException extends Exception {

	public PogresnoUnetKodException() {}
}
