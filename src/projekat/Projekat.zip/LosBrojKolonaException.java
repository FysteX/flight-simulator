package projekat;

public class LosBrojKolonaException extends Exception {

	public LosBrojKolonaException() {}

}
