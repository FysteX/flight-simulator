package projekat;

public class CitanjeIzFajlaException extends Exception {

	public CitanjeIzFajlaException() {}
}
