package projekat;

public class LoseUnetoVremeException extends Exception {

	public LoseUnetoVremeException() {}
}
