package projekat;

public class Timer extends Thread {

	private int time = 60;
	private boolean paused = false;
	
	private Aplikacija aplikacija;
	
	public Timer(Aplikacija aplikacija) {
		this.aplikacija = aplikacija;
	}
	
	public synchronized void pause() {
		paused = true;
	}
	
	public synchronized void unpause() {
		paused = false;
		this.notify();
	}
	
	@Override
	public void run() {
		try {
			while(!this.isInterrupted()) {
				Thread.sleep(1000);
				aplikacija.getScena().toggleRedFrame();
				synchronized(this) {
					if(!paused) {
						time--;
					}
					if(time == 5) {
						aplikacija.vremeIsticePrikaz();
					}
					if(time == 0) {
						aplikacija.gasiAplikaciju();
					}
				}
				System.out.println(time);
			}
		} catch (InterruptedException e) {}
	}
	
	public synchronized void restartujTajmer() {
		time = 60;
	}
	
	public synchronized int getTime() {
		return time;
	}

}
