package projekat;

public class PocetniAerodromNePostojiException extends Exception {

	public PocetniAerodromNePostojiException() {}

}
