package projekat;

public class KrajnjiAerodromNePostojiException extends Exception {

	public KrajnjiAerodromNePostojiException() {}

}
