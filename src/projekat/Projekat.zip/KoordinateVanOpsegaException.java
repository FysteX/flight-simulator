package projekat;

public class KoordinateVanOpsegaException extends Exception {

	public KoordinateVanOpsegaException() {}

}
