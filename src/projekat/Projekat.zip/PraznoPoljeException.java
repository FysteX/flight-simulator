package projekat;

public class PraznoPoljeException extends Exception {

	public PraznoPoljeException() {}

}
