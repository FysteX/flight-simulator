package projekat;

public class AerodromSaIstimKoordinatamaPostoji extends Exception {

	public AerodromSaIstimKoordinatamaPostoji() {}

}
