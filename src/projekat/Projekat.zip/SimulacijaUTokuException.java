package projekat;

public class SimulacijaUTokuException extends Exception {

	public SimulacijaUTokuException() {}

}
